import React, { useState } from 'react';
import Modal from '../components/Modal';

/* مكون صفحة إدارة الإطارات (Frames) */
const Frames = () => {
  /* بيانات وهمية للإطارات */
  const [frames, setFrames] = useState([
    { id: 1, brand: 'Ray-Ban', size: 'متوسط', price: 1500 },
    { id: 2, brand: 'Vogue', size: 'صغير', price: 1200 },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({ id: null, brand: '', size: '', price: '' });

  const openModal = (frame = { id: null, brand: '', size: '', price: '' }) => {
    setForm(frame);
    setIsModalOpen(true);
  };
  const closeModal = () => setIsModalOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.id) {
      setFrames(frames.map(f => (f.id === form.id ? form : f)));
    } else {
      const newId = frames.length > 0 ? Math.max(...frames.map(f => f.id)) + 1 : 1;
      setFrames([...frames, { ...form, id: newId }]);
    }
    closeModal();
  };
  const handleDelete = (id) => {
    setFrames(frames.filter(f => f.id !== id));
  };

  return (
    <div className="p-4 sm:p-6 w-full overflow-y-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">إدارة الإطارات</h1>
      <div className="flex justify-end mb-4">
        <button onClick={() => openModal()} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
          أضف إطارا جديدا
        </button>
      </div>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">العلامة التجارية</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الحجم</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">السعر</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {frames.map((frame) => (
              <tr key={frame.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{frame.brand}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{frame.size}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{frame.price}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button onClick={() => openModal(frame)} className="text-blue-600 hover:text-blue-900 transition-colors mr-2">تعديل</button>
                  <button onClick={() => handleDelete(frame.id)} className="text-red-600 hover:text-red-900 transition-colors">حذف</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Modal title={form.id ? 'تعديل إطار' : 'أضف إطار جديد'} isOpen={isModalOpen} onClose={closeModal}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">العلامة التجارية</label>
            <input type="text" name="brand" value={form.brand} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الحجم</label>
            <input type="text" name="size" value={form.size} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">السعر</label>
            <input type="number" name="price" value={form.price} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div className="flex justify-end space-x-2 mt-4">
            <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
              إلغاء
            </button>
            <button type="submit" className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
              حفظ
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Frames;