import React, { useState } from 'react';
import Modal from '../components/Modal';

/* مكون صفحة إدارة المستخدمين (Users) */
const Users = () => {
  /* بيانات وهمية للمستخدمين */
  const [users, setUsers] = useState([
    { id: 1, name: 'أحمد', email: 'ahmed@example.com', role: 'مسؤول' },
    { id: 2, name: 'فاطمة', email: 'fatima@example.com', role: 'موظف' },
    { id: 3, name: 'محمد', email: 'mohamed@example.com', role: 'موظف' },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({ id: null, name: '', email: '', role: '' });

  const openModal = (user = { id: null, name: '', email: '', role: '' }) => {
    setForm(user);
    setIsModalOpen(true);
  };
  const closeModal = () => setIsModalOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.id) {
      setUsers(users.map(u => (u.id === form.id ? form : u)));
    } else {
      const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
      setUsers([...users, { ...form, id: newId }]);
    }
    closeModal();
  };

  const handleDelete = (id) => {
    setUsers(users.filter(u => u.id !== id));
  };

  return (
    <div className="p-4 sm:p-6 w-full overflow-y-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">إدارة المستخدمين</h1>
      <div className="flex justify-end mb-4">
        <button onClick={() => openModal()} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
          أضف مستخدم جديد
        </button>
      </div>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الاسم</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">البريد الإلكتروني</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الدور</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user) => (
              <tr key={user.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{user.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.role}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button onClick={() => openModal(user)} className="text-blue-600 hover:text-blue-900 transition-colors mr-2">تعديل</button>
                  <button onClick={() => handleDelete(user.id)} className="text-red-600 hover:text-red-900 transition-colors">حذف</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Modal title={form.id ? 'تعديل مستخدم' : 'إضافة مستخدم جديد'} isOpen={isModalOpen} onClose={closeModal}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
            <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
            <input type="email" name="email" value={form.email} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الدور</label>
            <select name="role" value={form.role} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md">
              <option value="">اختر دورا</option>
              <option value="Admin">مسؤول</option>
              <option value="Employee">موظف</option>
            </select>
          </div>
          <div className="flex justify-end space-x-2 mt-4">
            <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
              إلغاء
            </button>
            <button type="submit" className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
              حفظ
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Users;