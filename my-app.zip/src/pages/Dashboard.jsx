import React, { useState } from 'react';

/* مكون صفحة لوحة التحكم (Dashboard) */
const Dashboard = () => {
  const [stats] = useState([
    { title: 'إجمالي المستخدمين', value: 150, color: 'bg-blue-500' },
    { title: 'العملاء', value: 85, color: 'bg-green-500' },
    { title: 'الإطارات', value: 240, color: 'bg-yellow-500' },
    { title: 'الطلبات', value: 125, color: 'bg-red-500' },
  ]);

  return (
    <div className="p-4 sm:p-6 w-full overflow-y-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">لوحة التحكم</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className={`p-6 rounded-lg shadow-md text-white ${stat.color}`}>
            <h3 className="text-lg font-semibold">{stat.title}</h3>
            <p className="text-4xl font-bold mt-2">{stat.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold text-gray-900 mb-4">الطلبات حسب الجنس</h3>
          <div className="flex h-64 justify-center items-end p-4 border-b border-gray-200">
            <div className="w-1/3 bg-blue-500 rounded-t-md h-[70%] flex flex-col items-center justify-end p-2 text-white font-bold">
              <span className="text-sm">70%</span>
              <span className="text-sm">ذكر</span>
            </div>
            <div className="w-1/3 bg-pink-500 rounded-t-md h-[50%] flex flex-col items-center justify-end p-2 text-white font-bold">
              <span className="text-sm">50%</span>
              <span className="text-sm">أنثى</span>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold text-gray-900 mb-4">إحصائيات شهرية</h3>
          <div className="flex h-64 justify-center items-end p-4 border-b border-gray-200">
            <div className="w-1/6 bg-green-500 rounded-t-md h-[40%] flex flex-col items-center justify-end p-1 text-white text-xs">يناير</div>
            <div className="w-1/6 bg-green-500 rounded-t-md h-[60%] flex flex-col items-center justify-end p-1 text-white text-xs">فبراير</div>
            <div className="w-1/6 bg-green-500 rounded-t-md h-[80%] flex flex-col items-center justify-end p-1 text-white text-xs">مارس</div>
            <div className="w-1/6 bg-green-500 rounded-t-md h-[55%] flex flex-col items-center justify-end p-1 text-white text-xs">أبريل</div>
            <div className="w-1/6 bg-green-500 rounded-t-md h-[75%] flex flex-col items-center justify-end p-1 text-white text-xs">ماي</div>
            <div className="w-1/6 bg-green-500 rounded-t-md h-[90%] flex flex-col items-center justify-end p-1 text-white text-xs">يونيو</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;