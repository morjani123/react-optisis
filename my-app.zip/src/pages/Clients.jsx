import React, { useState } from 'react';
import Modal from '../components/Modal';

/* مكون صفحة إدارة العملاء (Clients) */
const Clients = () => {
  /* بيانات وهمية للعملاء */
  const [clients, setClients] = useState([
    { id: 1, name: 'علي حسن', phone: '0612345678', age: 35, gender: 'ذكر' },
    { id: 2, name: 'سناء كريم', phone: '0623456789', age: 28, gender: 'أنثى' },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({ id: null, name: '', phone: '', age: '', gender: '' });

  const openModal = (client = { id: null, name: '', phone: '', age: '', gender: '' }) => {
    setForm(client);
    setIsModalOpen(true);
  };
  const closeModal = () => setIsModalOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.id) {
      setClients(clients.map(c => (c.id === form.id ? form : c)));
    } else {
      const newId = clients.length > 0 ? Math.max(...clients.map(c => c.id)) + 1 : 1;
      setClients([...clients, { ...form, id: newId }]);
    }
    closeModal();
  };
  const handleDelete = (id) => {
    setClients(clients.filter(c => c.id !== id));
  };

  return (
    <div className="p-4 sm:p-6 w-full overflow-y-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">إدارة العملاء</h1>
      <div className="flex justify-end mb-4">
        <button onClick={() => openModal()} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
          أضف عميلا جديدا
        </button>
      </div>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الاسم</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الهاتف</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">العمر</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الجنس</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {clients.map((client) => (
              <tr key={client.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{client.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.phone}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.age}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.gender}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button onClick={() => openModal(client)} className="text-blue-600 hover:text-blue-900 transition-colors mr-2">تعديل</button>
                  <button onClick={() => handleDelete(client.id)} className="text-red-600 hover:text-red-900 transition-colors">حذف</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Modal title={form.id ? 'تعديل عميل' : 'إضافة عميل جديد'} isOpen={isModalOpen} onClose={closeModal}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
            <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الهاتف</label>
            <input type="text" name="phone" value={form.phone} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">العمر</label>
            <input type="number" name="age" value={form.age} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الجنس</label>
            <select name="gender" value={form.gender} onChange={handleChange} required className="w-full px-3 py-2 border rounded-md">
              <option value="">اختر الجنس</option>
              <option value="Male">ذكر</option>
              <option value="Female">أنثى</option>
            </select>
          </div>
          <div className="flex justify-end space-x-2 mt-4">
            <button type="button" onClick={closeModal} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
              إلغاء
            </button>
            <button type="submit" className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
              حفظ
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Clients;