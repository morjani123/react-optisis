import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';

/* استيراد جميع الصفحات من مجلد pages */
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Messages from './pages/Messages';
import Frames from './pages/Frames';
import LensBrands from './pages/LensBrands';
import Fournisseurs from './pages/Fournisseurs';
import Clients from './pages/Clients';
import './App.css';
/* هذا هو المكون الرئيسي الذي يتحكم في عرض الصفحات */
export default function App() {
  const [currentPage, setCurrentPage] = useState('Login');

  /* دالة لعرض الصفحة الحالية بناءً على حالة currentPage */
  const renderPage = () => {
    switch (currentPage) {
      case 'Dashboard':
        return <Dashboard />;
      case 'Users':
        return <Users />;
      case 'Messages':
        return <Messages />;
      case 'Frames':
        return <Frames />;
      case 'LensBrands':
        return <LensBrands />;
      case 'Fournisseurs':
        return <Fournisseurs />;
      case 'Clients':
        return <Clients />;
      case 'Login':
      default:
        return <Login setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <AuthProvider>
      <div className="flex flex-col h-screen font-sans" dir="ltr">
        <Navbar setCurrentPage={setCurrentPage} />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar setCurrentPage={setCurrentPage} currentPage={currentPage} />
          <div className="flex-1 bg-gray-50 flex overflow-hidden">
            {renderPage()}
          </div>
        </div>
      </div>
    </AuthProvider>
  );
}