import React, { useState, createContext } from 'react';

/* إنشاء سياق (Context) للمصادقة */
const AuthContext = createContext();

/* مزود السياق الذي يحمل حالة تسجيل الدخول */
const AuthProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);

  /* دالة وهمية لتسجيل الدخول */
  const login = (email, password) => {
    if (email === 'admin@example.com' && password === 'password') {
      setIsLoggedIn(true);
      setUser({ name: 'Admin', email: 'admin@example.com' });
      return true;
    }
    return false;
  };

  /* دالة تسجيل الخروج */
  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
  };

  const value = { isLoggedIn, user, login, logout };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export { AuthContext, AuthProvider };