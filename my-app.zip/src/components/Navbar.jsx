import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

/* مكون شريط التنقل العلوي */
const Navbar = ({ setCurrentPage }) => {
  const { logout, user, isLoggedIn } = useContext(AuthContext);

  const handleLogout = () => {
    logout();
    setCurrentPage('Login');
  };

  if (!isLoggedIn) {
    return null;
  }

  return (
    <nav className="flex-none p-4 bg-gray-900 text-white shadow-md">
      <div className="flex justify-between items-center">
        <div className="text-xl font-bold">لوحة تحكم Optisis</div>
        <div className="flex items-center space-x-4">
          <span className="text-sm hidden sm:block">مرحبا بك، {user?.name || 'مستخدم'}!</span>
          <button onClick={handleLogout} className="bg-red-600 text-white text-sm font-bold py-1 px-3 rounded-md hover:bg-red-700 transition-colors">
            خروج
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;