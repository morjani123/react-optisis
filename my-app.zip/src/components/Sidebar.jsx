import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

/* مكون الشريط الجانبي للتنقل */
const Sidebar = ({ setCurrentPage, currentPage }) => {
  const { isLoggedIn } = useContext(AuthContext);

  const navItems = [
    { name: 'Dashboard', label: 'لوحة التحكم', icon: '🏠' },
    { name: 'Users', label: 'المستخدمون', icon: '👥' },
    { name: 'Messages', label: 'الرسائل', icon: '💬' },
    { name: 'Frames', label: 'الإطارات', icon: '🕶️' },
    { name: 'LensBrands', label: 'ماركات العدسات', icon: '🔬' },
    { name: 'Fournisseurs', label: 'الموردون', icon: '🚚' },
    { name: 'Clients', label: 'العملاء', icon: '👨‍👩‍👧‍👦' },
  ];

  if (!isLoggedIn) {
    return null;
  }

  return (
    <div className="w-16 sm:w-64 bg-gray-800 text-white p-4 flex-none transition-all duration-300">
      <ul className="space-y-2">
        {navItems.map((item) => (
          <li key={item.name}>
            <button
              onClick={() => setCurrentPage(item.name)}
              className={`flex items-center w-full py-2 px-3 rounded-md transition-colors ${
                currentPage === item.name
                  ? 'bg-blue-600 text-white'
                  : 'hover:bg-gray-700'
              }`}
            >
              <span className="text-2xl sm:text-xl mr-2">{item.icon}</span>
              <span className="hidden sm:block text-sm">{item.label}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;